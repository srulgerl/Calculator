﻿namespace testCAl;


[TestClass]
public sealed class TestCalculator
{
    [TestMethod]
    public void TestMethod1()
    {
    }
}
